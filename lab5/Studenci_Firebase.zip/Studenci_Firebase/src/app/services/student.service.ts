import { Injectable } from '@angular/core';

import { Student } from '../students/student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

 
  constructor() {
  
  }

  createStudent(student: Student): void {
  
  }

  updateStudent(key: string, value: any) {
   
  }

  deleteStudent(key: string) {
 
  }

  getStudentsList()  {
  
  }

   deleteAll() {
   }
    
}
